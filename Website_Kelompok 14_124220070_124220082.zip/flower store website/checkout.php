<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];
$email = $_SESSION['user_email'];


if(!isset($user_id)){
   header('location:login.php');
};

if(isset($_POST['upload'])){

    $nama_adopter = mysqli_real_escape_string($conn, $_POST['nama_adopter']);
    $no_telp_adopter = mysqli_real_escape_string($conn, $_POST['no_telp_adopter']);
    $alamat_adopter = mysqli_real_escape_string($conn, $_POST['alamat_adopter']);

    $bukti_pembayaran = $_FILES['bukti_pembayaran']['name'];
    $image_folter = 'uploaded_img/'.$bukti_pembayaran;

    $berhasil = mysqli_query($conn, "INSERT INTO `pesanan`(nama_adopter, no_telp_adopter, email_adopter, alamat_adopter, bukti_pembayaran) VALUES('$nama_adopter', '$no_telp_adopter', '$email', '$alamat_adopter', '$bukti_pembayaran')") or die('query failed');
    echo $berhasil;

    header('location:order.php');
   

    
    // $select_pesanan = mysqli_query($conn, "SELECT * FROM `pesanan` WHERE nama_adopter = '$nama_adopter' AND no_telp_adopter = '$no_telp_adopter' AND email_adopter = '$email_adopter' AND alamat_adopter = '$alamat_adopter'") or die('query failed');

  
    //     mysqli_query($conn, "INSERT INTO `pesanan`(user_id, nama_adopter, no_telp_adopter, email_adopter, alamat_adopter) VALUES('$user_id', '$nama_adopter', '$no_telp_adopter', '$email_adopter', '$alamat_adopter')") or die('query failed');
    //     $pesanan[] = 'pesanan sent successfully!';    
}

    


?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>checkout</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php @include 'header.php'; ?>

<section class="heading">
    <h3>checkout order</h3>
    <p> <a href="home.php">home</a> / checkout </p>
</section>

<section class="display-order">
    
</section>

<section class="checkout">

    <form action="checkout.php" method="POST" enctype="multipart/form-data">
        <h3>place your order</h3>

        <input type="text" name="nama_adopter" placeholder="enter your name" class="box" required> 
        <input type="number" name="no_telp_adopter" placeholder="enter your telp" class="box" required>
        <input type="text" name="alamat_adopter" placeholder="enter your address" class="box" required>
        <label for="bukti_pembayaran">Bukti Pembayaran</label> 
        <input type="file" placeholder="Bukti Pembayaran : " accept="image/jpg, image/jpeg, image/png" required class="box" name="bukti_pembayaran">
        <input type="submit" value="Adopt Now" name="upload" class="btn">
    </form>     

</section>


<?php @include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>
