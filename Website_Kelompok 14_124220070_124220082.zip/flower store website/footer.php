<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>contact info</h3>
            <p> <i class="fas fa-phone"></i> +6282856324695 </p>
            <p> <i class="fas fa-map-marker-alt"></i> Palembang, Indonesia </p>
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href="https://www.instagram.com/nayacathouseplg"><i class="fab fa-instagram"></i>instagram</a>
        </div>

    </div>

</section>