-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2024 at 04:52 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE `pesanan` (
  `user_id` int(100) NOT NULL,
  `nama_adopter` varchar(100) NOT NULL,
  `no_telp_adopter` varchar(15) NOT NULL,
  `email_adopter` varchar(100) NOT NULL,
  `alamat_adopter` text NOT NULL,
  `bukti_pembayaran` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`user_id`, `nama_adopter`, `no_telp_adopter`, `email_adopter`, `alamat_adopter`, `bukti_pembayaran`) VALUES
(17, 'bunga', '2147483647', 'bunga@gmail.com', 'jakarta', ''),
(19, 'lenan', '025', 'bunga@gmail.com', 'jakarta', ''),
(34, 'puspo', '5566', 'io@gmail.com', 'seturan', ''),
(40, 'ty', '963', 'puspo@gmail.com', 'seturan', 'bungo.jpg'),
(41, 'op', '258', 'fakiku@gmail.com', 'chatime', 'bloomnation.jpg'),
(42, 'bunga', '082159852369', 'bunga@gmail.com', 'bali', 'pink roses.jpg'),
(43, 'bunga', '082159852369', 'bunga@gmail.com', 'bali', 'pink roses.jpg'),
(44, 'puspo', '012346743213', 'puspo@gmail.com', 'seturan', 'Monas.jpg'),
(45, 'lili', '089898989', 'bunga@gmail.com', 'pwrj', 'load more (7).png'),
(46, 'bunga', '09090', 'lenan@gmail.com', 'jakarta', 'load more (5).png'),
(47, 'dewi', '02586562', 'dewi@gmail.com', 'bali', 'load more (5).png'),
(48, 'dewi', '0147', 'lenan@gmail.com', 'seturan', 'load more (4).png'),
(49, 'lenan', '0918293212', 'lenan@gmail.com', 'bali', 'Monas.jpg'),
(50, 'dewi', '082123654789', 'dewi@gmail.com', 'bali', 'load more (5).png'),
(51, 'dhiya', '01556', 'dhiya@gmail.com', 'jakarta', 'about-img-1.png'),
(52, 'dhiya', '082456369874', 'lenan@gmail.com', 'bali', 'bungo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `details` varchar(500) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `details`, `price`, `image`) VALUES
(13, 'cemot', 'Jenis kelamin: perempuan\r\nUmur: 2 bulan\r\nKeadaan: sehat\r\nRas kucing: persia', 800000, 'cat 1.jpg'),
(15, 'bowwy', 'Jenis kelamin: laki-laki\r\nUmur: 1 bulan\r\nKeadaan: sehat\r\nRas kucing: persia', 1500000, 'cat 2.jpg'),
(16, 'zel', 'Jenis kelamin: laki-laki\r\nUmur: 3 bulan\r\nKeadaan: sehat\r\nRas kucing: persia', 4000000, 'cat 3.jpg'),
(17, 'oa', 'Jenis kelamin: laki-laki\r\nUmur: 2 bulan\r\nKeadaan: sehat\r\nRas kucing: siam', 1400000, 'cat 4.jpg'),
(18, 'joko', 'Jenis kelamin: perempuan\r\nUmur: 5 bulan\r\nKeadaan: sehat\r\nRas kucing: anggora', 2000000, 'cat 5.jpg'),
(19, 'pus', 'Jenis kelamin: perempuan\r\nUmur: 4 bulan\r\nKeadaan: sehat\r\nRas kucing: siam', 650000, 'cat 6.jpg'),
(20, 'oek', 'Jenis kelamin: laki-laki\r\nUmur: 5 bulan\r\nKeadaan: sehat\r\nRas kucing: anggora', 700000, 'cat 7.jpg'),
(21, 'ica', 'Jenis kelamin: perempuan\r\nUmur: 1 bulan\r\nKeadaan: sehat\r\nRas kucing: anggora', 600000, 'cat 8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `user_type`) VALUES
(10, 'admin A', 'admin01@gmail.com', '698d51a19d8a121ce581499d7b701668', 'admin'),
(14, 'user A', 'user01@gmail.com', '698d51a19d8a121ce581499d7b701668', 'user'),
(15, 'user B', 'user02@gmail.com', '698d51a19d8a121ce581499d7b701668', 'user'),
(16, 'bunga', 'bungarmdhniii@gmail.com', '80219675a4b4f2bb1fa1e48fe8397f30', 'admin'),
(17, 'lenan', 'lenan@gmail.com', '36bb8b50287ce08ccbe3f827b42028a7', 'user'),
(18, 'dewi', 'dewi@gmail.com', 'ed1d859c50262701d92e5cbf39652792', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
