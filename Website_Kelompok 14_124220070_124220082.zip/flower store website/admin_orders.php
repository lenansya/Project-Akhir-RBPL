<?php

@include 'config.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:login.php');
};

if(isset($_POST['pesanan'])){

   $nama_adopter = mysqli_real_escape_string($conn, $_POST['nama_adopter']);
   $no_telp_adopter = mysqli_real_escape_string($conn, $_POST['no_telp_adopter']);
   $email_adopter = mysqli_real_escape_string($conn, $_POST['email_adopter']);
   $alamat_adopter = mysqli_real_escape_string($conn, $_POST['alamat_adopter']);
   $bukti_pembayaran = $_FILES['bukti_pembayaran']['name'];
   $image_folter = 'uploaded_img/'.$bukti_pembayaran;

   $select_pesanan_nama_adopter = mysqli_query($conn, "SELECT nama_adopter FROM `pesanan` WHERE nama_adopter = '$nama_adopter'") or die('query failed');

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Admin Panel</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">

</head>
<body>
   
<?php @include 'admin_header.php'; ?>

<section class="placed-orders">

   <h1 class="title">orders</h1>

   <div class="box-container">

      <?php
      
      $select_pesanan = mysqli_query($conn, "SELECT * FROM `pesanan`") or die('query failed');
      if(mysqli_num_rows($select_pesanan) > 0){
         while($fetch_pesanan = mysqli_fetch_assoc($select_pesanan)){
      ?>
      <div class="box">
         <p> user id : <span><?php echo $fetch_pesanan['user_id']; ?></span> </p>
         <p> Nama adopter: <span><?php echo $fetch_pesanan['nama_adopter']; ?></span> </p>
         <p> Telepon adopter: <span><?php echo $fetch_pesanan['no_telp_adopter']; ?></span> </p>
         <p> Email adopter: <span><?php echo $fetch_pesanan['email_adopter']; ?></span> </p>
         <p> Alamat adopter : <span><?php echo $fetch_pesanan['alamat_adopter']; ?></span> </p>
         <p> Bukti pembayaran : <span><?php echo $fetch_pesanan['bukti_pembayaran']; ?></span> </p>
      </div>

      <?php
         }
      }else{
         echo '<p class="empty">no orders placed yet!</p>';
      }
      ?>
   </div>

</section>













<script src="js/admin_script.js"></script>

</body>
</html>