<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];
$email = $_SESSION['user_email'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>orders</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php @include 'header.php'; ?>

<section class="heading">
    <h3>your orders</h3>
    <p> <a href="home.php">home</a> / order </p>
</section>

<section class="placed-orders">

    <h1 class="title">placed orders</h1>

    <div class="box-container">

    <?php
        $select_pesanan = mysqli_query($conn, "SELECT * FROM pesanan WHERE email_adopter = '$email'") or die('query failed');
        if(mysqli_num_rows($select_pesanan) > 0){
            while($fetch_pesanan = mysqli_fetch_assoc($select_pesanan)){
    ?>

    <div class="box">
        <p> User id : <span><?php echo $fetch_pesanan['user_id']; ?></span> </p>
        <p> Nama adopter: <span><?php echo $fetch_pesanan['nama_adopter']; ?></span> </p>
        <p> Telepon adopter: <span><?php echo $fetch_pesanan['no_telp_adopter']; ?></span> </p>
        <p> Email adopter: <span><?php echo $fetch_pesanan['email_adopter']; ?></span> </p>
        <p> Alamat adopter : <span><?php echo $fetch_pesanan['alamat_adopter']; ?></span> </p>
        <p> Bukti pembayaran : <span><?php echo $fetch_pesanan['bukti_pembayaran']; ?></span> </p>
    </div>

    <?php
        }
    }else{
        echo '<p class="empty">no orders placed yet!</p>';
    }
    ?>
    </div>

</section>







<?php @include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>